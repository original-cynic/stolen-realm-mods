An enormous thank you to BFiveAlive for creating the framework for this mod. Without their work, this would not have been possible. You can find more of their work here:

https://github.com/BFiveAlive/stolen-realm-mods/

******

Instructions:

Just paste these files into your Stolen Realm installation directory, then launch the game. Easy!

Example install path:  

C:\Program Files (x86)\Steam\steamapps\common\Stolen Realm\

The folders/files you need to copy there:
BepInEx
.doorstop_version
doorstop_config
winhttp.dll

I hope you enjoy the new classes! :)
