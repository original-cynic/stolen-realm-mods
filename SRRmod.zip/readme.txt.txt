Just paste these files into your Stolen Realm installation directory, then launch the game. Easy!

Example install path:  

C:\Program Files (x86)\Steam\steamapps\common\Stolen Realm\

The folders/files you need to copy there:

BepInEx
.doorstop_version
doorstop_config
winhttp.dll

I hope you enjoy the new classes! :)

